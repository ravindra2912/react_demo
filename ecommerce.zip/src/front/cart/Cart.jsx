import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import AxiosReq from "../AxiosReq";
import { useSelector } from "react-redux";

function Cart() {
    const cart = useSelector((state) => state.cart);
    const navigate = useNavigate(); // Initialize navigation
    const [cartData, setCartData] = useState(Array);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        console.log(cart);
        setCartData(cart);
        // getCart()
    }, [])

    async function getCart() {
        window.scrollTo(0, 0);
        await AxiosReq(`carts/28`, '', 'GET', navigate)
            // await AxiosReq(`carts/user/5`, '', 'GET', navigate)
            .then((response) => {
                console.log(response);
                if (response.success) {
                    setCartData(response.data);
                }
            })
            .catch((error) => {
                console.log(error);

            }).finally(() => {
                setLoading(false);
            });
    }
    console.log(cartData.products)
    console.log(cartData.products)
    return (

        <>
            <section className="container mb-3 cart">
                <div className="row">
                    <div className="col-md-8 col-12">
                        <h3>Cart</h3>
                        <hr />
                        {
                            cartData && cartData.length > 0 ?
                                <table className="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            cartData.map((item, index) => {
                                                return (
                                                    <tr key={index}>
                                                        <td>
                                                            <img className="pimg" src={item.thumbnail} />
                                                            {item.title}
                                                        </td>
                                                        <td>${item.price}</td>
                                                        <td>{item.quantity}</td>
                                                        <td>${item.price * item.quantity}</td>
                                                    </tr>
                                                )
                                            })
                                        }

                                    </tbody>
                                </table>
                                :
                                loading ? <h1>loading ...</h1> : <h1>Cart is empty</h1>

                        }

                    </div>
                    <div className="col-md-4 col-12">
                        <h3>Cart Summary</h3>
                        <hr />
                        <div className="form-group">
                            <label htmlFor="coupon">Coupon Code</label>
                            <input type="text" className="form-control" id="coupon" />
                        </div>
                        <button className="btn btn-primary mt-2">Apply Coupon</button>
                        <hr />
                        <h4>Cart Total</h4>
                        <hr />
                        <table className="table table-secondary border">
                            <thead>
                                <tr>
                                    <th>Subtotal</th>
                                    <th>${cartData.total}</th>
                                </tr>
                                <tr>
                                    <th>Discount</th>
                                    <th>${cartData.total - cartData.discountedTotal}</th>
                                </tr>
                                <tr>
                                    <th>Total</th>
                                    <th>${cartData.discountedTotal}</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div className="col-12 text-end">
                        <Link to="/products" className="btn btn-primary me-2">Continue Shopping</Link>
                        <button className="btn btn-primary">Checkout</button>
                    </div>

                </div>
            </section>

        </>
    )
}

export default Cart;