import { combineReducers, createSlice } from "@reduxjs/toolkit";
import CartSlice from "./slices/CartSlice";

const rootReducer = combineReducers({
    cart: CartSlice
});

export default rootReducer;