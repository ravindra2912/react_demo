import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "../front/home/Home";
import Main from "../front/Layout/Main";
import Products from "../front/products/Products";
import ProductDetails from "../front/products/ProductDetails";
import PageWith404Handler from "../front/Layout/PageWith404Handler";
import ProductImageZoom from "../front/products/ProductImageZoom";
import Cart from '../front/cart/Cart';



function MainRoutes() {
    return (
        <BrowserRouter>
            <Routes>
                <Route element={<Main />} >
                    <Route path="" element={<Home />} />
                    <Route path="products" element={<Products />} />
                    {/* <Route path="product/:slug" element={<ProductImageZoom />} /> */}
                    <Route path="product/:slug" element={<ProductDetails />} />
                    <Route path="cart" element={<Cart />} />
                    <Route path="*" element={<PageWith404Handler />} />
                </Route>

            </Routes>
        </BrowserRouter>
    );
}



export default MainRoutes;